**Libertades tomadas**
1) Para la validacion del numero de telefono movil cree un regex que verificara si el numero introducido tenia la forma " +12-123-123-123 " es decir que empezara con un "+"
y se separara cada 3 caracteres por un "-".

2) Para la pagina de informacion-producto decidi que la imagen de 1280x1024 sea un div que esta oculto hasta que se hace click en la imagen de 640x480.
Y que luego si se realiza un click en la imagen grande esta se oculte nuevamente

3) Cree un nav-bar como menu para poder tener acceso a el en todas las paginas asi poder volver al inicio o moverse de pedido a producto rapidamente.

4) Para la notificacion de errores cree alerts para cada tipo de error y si es posible la casilla con el primer fallo(estos se revisan de arriba hacia abajo) se vuelve roja.

