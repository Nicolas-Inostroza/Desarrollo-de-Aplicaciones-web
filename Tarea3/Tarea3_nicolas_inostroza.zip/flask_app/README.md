Entregue la tarea sin ningun pedido y producto colocado y con la carpeta uploads vacia.

Por alguna razon la paginacion no me funciona para la pagina 2 me refiero a que no me da los pedidos/productos desde el 5 al 10
sino que de el 5 en adelante. Esto es raro porque lo intente cuando devolvia pedidos/productos desde el 10 al 15 y si funcionaba bien 
al igual que el de 0 a 5.